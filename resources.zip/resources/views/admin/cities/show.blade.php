@extends('layouts.admin')

@section('styles')
@endsection


@section('content')

Show

@stop

@section('scripts')
@endsection
